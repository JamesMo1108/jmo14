#!/usr/bin/env python3
''' template for ops435 assignment 1 script
    put your script level docstring here...
    you can have more than one line
'''

import os
import sys

def after(today):
    '''
    put your function level docstring here ...
    '''
    ...

    return next_day

def before(today):
    '''
    put your function level docstring here ..
    '''
    ...

    return previous_day

...

def dbda(date, days):
    ...
    setup loop:
        call after() of before() as appropriate
    return target_date

if __name__ == "__main__":
  
   ... processing command line arguments ...
   ... call dbda()
   ...
   ... output the result
  
