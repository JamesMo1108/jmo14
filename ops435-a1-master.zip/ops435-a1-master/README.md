# ops435-a1
# Resource, sample code, and test data

For the detail specification, please go to
https://wiki.cdot.senecacollege.ca/wiki/OPS435_Python3_Assignment_1

Due date: February 14, 2020 before mid-night

